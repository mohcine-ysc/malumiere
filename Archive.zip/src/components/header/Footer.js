import React from 'react';
import { AiFillFacebook,AiFillInstagram,AiFillMail } from "react-icons/ai";


function Footer() {
  return (
    <div className='container-fluid text-bg-dark py-5'>
        <div className="container d-none d-sm-block">
             <div className="row ">
                <ul className="d-flex gap-4 justify-content-center">
                    <li className="nav-item">
                        <a className="nav-link foot" href="#">Qui sommes nous ?</a>
                    </li>
                    <li className="nav-item">
                        <a className="nav-link foot" href="#">Blog</a>
                    </li>
                    <li className="nav-item">
                        <a className="nav-link foot">FAQS</a>
                    </li>
                    <li className="nav-item">
                        <a className="nav-link foot">Contactez-nous</a>
                    </li>
                    <li className="nav-item">
                        <a className="nav-link foot">Suivi de commande</a>
                    </li>
                    <li className="nav-item">
                        <a className="nav-link foot">Conditions générales de vente</a>
                    </li>
                </ul>
            </div>
            <div className="row ">
                <div className="col-6 foot">
                    © 2023 Ma lumiere
                </div>
                <div className="col-6">
                    <ul className="d-flex gap-4 justify-content-end">
                        <li className="nav-item">
                            <a className="nav-link foot" href="#"><AiFillFacebook/></a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link foot" href="#"><AiFillInstagram/></a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link foot" href="#"><AiFillMail/></a>
                        </li>

                    </ul>
                </div>
            </div>
        </div>
        <div className="d-block d-sm-none">
        <div className="container">
        <div className="row mb-5">
                <div className="col-6 foot">
                    © 2023 Ma lumiere
                </div>
                <div className="col-6">
                    <ul className="d-flex gap-4 justify-content-end">
                        <li className="nav-item">
                            <a className="nav-link foot" href="#"><AiFillFacebook/></a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link foot" href="#"><AiFillInstagram/></a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link foot" href="#"><AiFillMail/></a>
                        </li>

                    </ul>
                </div>
                <div className="mb-10"></div>
            </div>
            
        </div>
        </div>
    </div>
  )
}

export default Footer