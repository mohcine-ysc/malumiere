import React from 'react'
import Logo from '../../images/logo.png'
import './header.css';
import {  Link } from 'react-router-dom';


import { AiOutlineSearch,AiOutlineUser,AiOutlineHeart,AiOutlineShoppingCart,AiOutlinePhone } from "react-icons/ai";

function NavBar() {
  return (
    <div className='container-fluid py-2 shadow-sm d-none d-sm-block'>
        <div className="row">
            <div className="col-5">
                <ul className="d-flex gap-2 py-4">
                    <li className="nav-item">
                        <Link to='/shop' className="nav-link" href="#">Tous les produits</Link>
                    </li>
                    <li className="nav-item">
                        <Link to='/new'  className="nav-link" href="#">Nouvelle collection</Link>
                    </li>
                    <li className="nav-item">
                        <Link to='/promo'  className="nav-link">Promo</Link>
                    </li>
                    <li className="nav-item">
                        <Link to='#' className="nav-link">Categories</Link>
                    </li>
                    <li className="nav-item">
                        <Link to='/espace-pro'  className="nav-link">Espace pro</Link>
                    </li>
                </ul>
            </div>
            <div className="col-2 position-relative">
                <Link to='/'><img src={Logo} alt="logo" className='logo position-absolute start-50 translate-middle-x'  /></Link>
            </div>
            <div className="col-5">
                 <ul className=" d-flex gap-3 justify-content-end py-4 mx-5">
                    <li className="nav-item">
                        <a className="nav-link" href="#"><AiOutlineSearch/></a>
                    </li>
                    <li className="nav-item">
                    <a className="nav-link" href="#"><AiOutlinePhone/></a>
                     </li>

                    <li className="nav-item">
                        <a className="nav-link"><AiOutlineHeart/></a>
                    </li>
                    <li className="nav-item">
                        <a className="nav-link" href="#"><AiOutlineUser/></a>
                    </li>

                    <li className="nav-item">
                    <a className="nav-link position-relative"><AiOutlineShoppingCart/><span className='position-absolute top-1 end-1'>0</span></a>
                </li>
                </ul>
            </div>
        
        </div>
    </div>  
  )
}

export default NavBar
