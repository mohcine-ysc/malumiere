import React from 'react'
import NavBar from './NavBar'
import NavMobile from './NavMobile'
function Header() {
  return (
    <div>
    <div className='container-fluid text-bg-dark '>
         <p className='text-center py-3'>TOUS NOS LUMINAIRES SONT LIVRÉ(S) AVEC LEURS AMPOULE(S) LED OFFERTE(S)</p>
    </div>
    <NavBar/>
    <NavMobile/>
    </div>
  )
}

export default Header
