import React ,{useState } from 'react'
import Logo from '../../images/logo.png'
import { AiOutlineHeart,AiOutlineShoppingCart,AiOutlinePhone,AiOutlineMenu } from "react-icons/ai";


function NavMobile() {
    const [sidebarVisible, setSidebarVisible] = useState(false);
    const toggleSidebar = () => setSidebarVisible(!sidebarVisible);
  return (
    <div className='container-fluid py-2 shadow-sm d-block d-sm-none'>
        <div className="row">
        <div className="col-5">
             <div className="py-4" href="#" onClick={toggleSidebar}>
                <AiOutlineMenu />
            </div>
            {sidebarVisible && (
                <div className={('sidebar', {visible: sidebarVisible})}>
                <div class="offcanvas offcanvas-start show" tabindex="-1" id="offcanvas" aria-labelledby="offcanvasLabel">
                    <div class="offcanvas-header">
                        <h5 class="offcanvas-title" id="offcanvasLabel">Menu</h5>
                        <button type="button" class="btn-close" onClick={toggleSidebar}></button>
                    </div>
                    <div class="offcanvas-body">
                    <ul className=" nav flex-column">
                    <li className="nav-item">
                        <a className="nav-link" href="#">Tous les produits</a>
                    </li>
                    <li className="nav-item">
                        <a className="nav-link" href="#">Nouvelle collection</a>
                    </li>
                    <li className="nav-item">
                        <a className="nav-link">Promo</a>
                    </li>
                    <li className="nav-item">
                        <a className="nav-link">Categories</a>
                    </li>
                    <li className="nav-item">
                        <a className="nav-link">Espace pro</a>
                    </li>
                </ul>
                    </div>
                    </div>
                </div>
             )}
        </div>
        <div className="col-2 position-relative">
        <img src={Logo} alt="logo" className='logo position-absolute start-50 translate-middle-x'  />
        </div>
        <div className="col-5">
            <ul className=" d-flex gap-2 justify-content-end py-4 mr-2">
                <li className="nav-item">
                    <a className="nav-link" href="#"><AiOutlinePhone/></a>
                </li>

                <li className="nav-item">
                    <a className="nav-link"><AiOutlineHeart/></a>
                </li>
                <li className="nav-item">
                    <a className="nav-link position-relative"><AiOutlineShoppingCart/>
                    <span className='position-absolute top-1 end-1'>0</span></a>
                </li>
            </ul>
        </div>
        </div>

      </div>
  )
}

export default NavMobile