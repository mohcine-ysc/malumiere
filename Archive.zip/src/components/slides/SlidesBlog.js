import React, { Component } from 'react'
import Slider from "react-slick";
import './slides.css'
import { AiOutlineHeart} from "react-icons/ai";
export class SlidesBlog extends Component {
    render() {
        var settings = {
          dots: false,
          infinite: true,
          speed: 500,
          slidesToShow: 4,
          slidesToScroll: 4,
          initialSlide: 0,
          lazyLoad: true,
          autoplay: true,
          autoplaySpeed: 2000,
          responsive: [
            {
              breakpoint: 1024,
              settings: {
                slidesToShow: 3,
                slidesToScroll: 3,
                infinite: true,
                dots: false
              }
            },
            {
              breakpoint: 600,
              settings: {
                slidesToShow: 2,
                slidesToScroll: 2,
                initialSlide: 2
              }
            },
            {
              breakpoint: 480,
              settings: {
                slidesToShow: 1,
                slidesToScroll: 1
              }
            }
          ]
        };
        return (
          <div>
            <Slider {...settings}>
              <div className="mx-2">
                    <div className="card">
                        <div className="position-relative">
                            <img src="https://picsum.photos/317/225" className="card-img-top" alt="..."/>
                        </div>
                        <div className="card-body border border-0">
                            <span className="bl-date">29 septembre 2021</span>
                            <a className="bl-title" href="#">Quel style de luminaire choisir selon l'ambiance voulue ?</a>
                        </div>
                    </div>
              </div>
              <div className="mx-2">
                    <div className="card">
                        <div className="position-relative">
                            <img src="https://picsum.photos/317/225" className="card-img-top" alt="..."/>
                        </div>
                        <div className="card-body border border-0">
                            <span className="bl-date">29 septembre 2021</span>
                            <a className="bl-title" href="#">Quel style de luminaire choisir selon l'ambiance voulue ?</a>
                        </div>
                    </div>
              </div>
              <div className="mx-2">
                <div className="card">
                    <div className="position-relative">
                        <img src="https://picsum.photos/317/225" className="card-img-top" alt="..."/>
                    </div>
                    <div className="card-body border border-0">
                        <span className="bl-date">29 septembre 2021</span>
                        <a className="bl-title" href="#">Quel style de luminaire choisir selon l'ambiance voulue ?</a>
                    </div>
                </div>
              </div>
              <div className="mx-2">
                <div className="card">
                    <div className="position-relative">
                        <img src="https://picsum.photos/317/225" className="card-img-top" alt="..."/>
                    </div>
                    <div className="card-body border border-0">
                        <span className="bl-date">29 septembre 2021</span>
                        <a className="bl-title" href="#">Quel style de luminaire choisir selon l'ambiance voulue ?</a>
                    </div>
                </div>
              </div>
              <div className="mx-2">
              <div className="card">
                  <div className="position-relative">
                      <img src="https://picsum.photos/317/225" className="card-img-top" alt="..."/>
                  </div>
                  <div className="card-body border border-0">
                      <span className="bl-date">29 septembre 2021</span>
                      <a className="bl-title" href="#">Quel style de luminaire choisir selon l'ambiance voulue ?</a>
                  </div>
              </div>
              </div>
              <div className="mx-2">
                    <div className="card">
                        <div className="position-relative">
                            <img src="https://picsum.photos/317/225" className="card-img-top" alt="..."/>
                        </div>
                        <div className="card-body border border-0">
                            <span className="bl-date">29 septembre 2021</span>
                            <a className="bl-title" href="#">Quel style de luminaire choisir selon l'ambiance voulue ?</a>
                        </div>
                    </div>
              </div>
              <div className="mx-2">
                <div className="card">
                    <div className="position-relative">
                        <img src="https://picsum.photos/317/225" className="card-img-top" alt="..."/>
                    </div>
                    <div className="card-body border border-0">
                        <span className="bl-date">29 septembre 2021</span>
                        <a className="bl-title" href="#">Quel style de luminaire choisir selon l'ambiance voulue ?</a>
                    </div>
                </div>
              </div>
              <div className="mx-2">
                <div className="card">
                    <div className="position-relative">
                        <img src="https://picsum.photos/317/225" className="card-img-top" alt="..."/>
                    </div>
                    <div className="card-body border border-0">
                        <span className="bl-date">29 septembre 2021</span>
                        <a className="bl-title" href="#">Quel style de luminaire choisir selon l'ambiance voulue ?</a>
                    </div>
                </div>
              </div>
            </Slider>
          </div>
        );
}
}

export default SlidesBlog
