import React, { Component } from 'react';
import img1 from '../../images/1.png'
import img2 from '../../images/2.png'
import "slick-carousel/slick/slick.css"; 
import "slick-carousel/slick/slick-theme.css";
import Slider from 'react-slick'
import './slides.css'


class Slider1 extends Component {
  render() {
    const settings = {
      dots: false,
      infinite: true,
      lazyLoad: true,
      speed: 500,
      slidesToShow: 1,
      slidesToScroll: 1
    };
    return (
      <div>
        <Slider {...settings}>
          <div>
            <img src={img1} className='w-100'/>
                <div className="carousel-caption2 d-none d-md-block">
                    <h5>First slide label</h5>
                    <p>Some representative placeholder content for the first slide.</p>
                </div>
          </div>
          <div>
            <img src={img2} className='w-100'/>
                <div className="carousel-caption2 d-none d-md-block">
                    <h5>First slide label</h5>
                    <p>Some representative placeholder content for the first slide.</p>
                </div>
          </div>
        </Slider>
      </div>
    );
  }
}

export default Slider1;

