import React, { Component,useEffect, useState } from 'react'
import Slider from "react-slick";
import './slides.css'
import { AiOutlineHeart,AiOutlineShoppingCart} from "react-icons/ai";
 

export class Slideprom extends Component {
    
    render()     
    {
        var settings = {
          dots: false,
          infinite: true,
          speed: 500,
          slidesToShow: 4,
          slidesToScroll: 4,
          initialSlide: 0,
          lazyLoad: true,
          autoplay: true,
          autoplaySpeed: 2000,
          responsive: [
            {
              breakpoint: 1024,
              settings: {
                slidesToShow: 3,
                slidesToScroll: 3,
                infinite: true,
                dots: false
              }
            },
            {
              breakpoint: 600,
              settings: {
                slidesToShow: 2,
                slidesToScroll: 2,
                initialSlide: 2
              }
            },
            {
              breakpoint: 480,
              settings: {
                slidesToShow: 2,
                slidesToScroll: 2
              }
            }
          ]
        };
        
        return (
          <div>
            <Slider {...settings}>
                <div className="mx-2">
                        <div className="card">
                        <div className="position-relative">
                            <img src="https://malumiere.ma/wp-content/uploads/2021/09/AP-206-3.jpg" className="card-img-top" alt="images"/>
                            <span className="position-absolute top-1  translate-middle ">
                                <span>20%</span>
                            </span>
                        </div>
                        <div className="card-body border border-0">
                            <h4 className='f-z-14'>Applique murale Auréole</h4>
                            <div className="d-flex justify-content-between">
                                <p  className="text-prim">1150 DHS</p>
                                <div className="d-flex gap-2">
                                <a className="card-link" href="#"><AiOutlineHeart/></a>
                                <a className="ncard-link" href="#"><AiOutlineShoppingCart/></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="mx-2">
                        <div className="card">
                        <div className="position-relative">
                            <img src="https://malumiere.ma/wp-content/uploads/2021/09/AP-203-2.jpg" className="card-img-top" alt="images"/>
                            <span className="position-absolute top-1  translate-middle ">
                                <span>20%</span>
                            </span>
                        </div>
                        <div className="card-body border border-0">
                            <h4 className='f-z-14'>Applique murale Botanica</h4>
                            <div className="d-flex justify-content-between">
                                <p  className="text-prim">737 DHS</p>
                                <div className="d-flex gap-2">
                                <a className="card-link" href="#"><AiOutlineHeart/></a>
                                <a className="ncard-link" href="#"><AiOutlineShoppingCart/></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="mx-2">
                        <div className="card">
                        <div className="position-relative">
                            <img src="https://malumiere.ma/wp-content/uploads/2021/09/AP-204-2.jpg" className="card-img-top" alt="images"/>
                            <span className="position-absolute top-1  translate-middle ">
                                <span>20%</span>
                            </span>
                        </div>
                        <div className="card-body border border-0">
                            <h4 className='f-z-14'>Applique murale Carla droiture</h4>
                            <div className="d-flex justify-content-between">
                                <p  className="text-prim">538 DHS</p>
                                <div className="d-flex gap-2">
                                <a className="card-link" href="#"><AiOutlineHeart/></a>
                                <a className="ncard-link" href="#"><AiOutlineShoppingCart/></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="mx-2">
                        <div className="card">
                        <div className="position-relative">
                            <img src="https://malumiere.ma/wp-content/uploads/2021/09/AP-205-3.jpg" className="card-img-top" alt="images"/>
                            <span className="position-absolute top-1  translate-middle ">
                                <span>20%</span>
                            </span>
                        </div>
                        <div className="card-body border border-0">
                            <h4 className='f-z-14'>Applique murale Carla méditation</h4>
                            <div className="d-flex justify-content-between">
                                <p  className="text-prim">650 DHS</p>
                                <div className="d-flex gap-2">
                                <a className="card-link" href="#"><AiOutlineHeart/></a>
                                <a className="ncard-link" href="#"><AiOutlineShoppingCart/></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="mx-2">
                        <div className="card">
                        <div className="position-relative">
                            <img src="https://malumiere.ma/wp-content/uploads/2021/09/AP-200-2.jpg" className="card-img-top" alt="images"/>
                            <span className="position-absolute top-1  translate-middle ">
                                <span>20%</span>
                            </span>
                        </div>
                        <div className="card-body border border-0">
                            <h4 className='f-z-14'>Applique murale CAROLINA</h4>
                            <div className="d-flex justify-content-between">
                                <p  className="text-prim">620 DHS</p>
                                <div className="d-flex gap-2">
                                <a className="card-link" href="#"><AiOutlineHeart/></a>
                                <a className="ncard-link" href="#"><AiOutlineShoppingCart/></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="mx-2">
                        <div className="card">
                        <div className="position-relative">
                            <img src="https://malumiere.ma/wp-content/uploads/2021/09/AP-207-5.jpg" className="card-img-top" alt="images"/>
                            <span className="position-absolute top-1  translate-middle ">
                                <span>20%</span>
                            </span>
                        </div>
                        <div className="card-body border border-0">
                            <h4 className='f-z-14'>Applique murale Lidia</h4>
                            <div className="d-flex justify-content-between">
                                <p  className="text-prim">1190 DHS</p>
                                <div className="d-flex gap-2">
                                <a className="card-link" href="#"><AiOutlineHeart/></a>
                                <a className="ncard-link" href="#"><AiOutlineShoppingCart/></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="mx-2">
                        <div className="card">
                        <div className="position-relative">
                            <img src="https://malumiere.ma/wp-content/uploads/2021/09/AP-202-3.jpg" className="card-img-top" alt="images"/>
                            <span className="position-absolute top-1  translate-middle ">
                                <span>20%</span>
                            </span>
                        </div>
                        <div className="card-body border border-0">
                            <h4 className='f-z-14'>Applique murale Lizzy</h4>
                            <div className="d-flex justify-content-between">
                                <p  className="text-prim">388 DHS</p>
                                <div className="d-flex gap-2">
                                <a className="card-link" href="#"><AiOutlineHeart/></a>
                                <a className="ncard-link" href="#"><AiOutlineShoppingCart/></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="mx-2">
                        <div className="card">
                        <div className="position-relative">
                            <img src="https://malumiere.ma/wp-content/uploads/2021/09/AP-201-2.jpg" className="card-img-top" alt="images"/>
                            <span className="position-absolute top-1  translate-middle ">
                                <span>20%</span>
                            </span>
                        </div>
                        <div className="card-body border border-0">
                            <h4 className='f-z-14'>Applique murale Lizzy</h4>
                            <div className="d-flex justify-content-between">
                                <p  className="text-prim">820 DHS</p>
                                <div className="d-flex gap-2">
                                <a className="card-link" href="#"><AiOutlineHeart/></a>
                                <a className="ncard-link" href="#"><AiOutlineShoppingCart/></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </Slider>
          </div>
        );
}
}

export default Slideprom
