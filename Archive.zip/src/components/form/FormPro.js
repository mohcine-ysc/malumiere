
import React, { useState } from 'react';
import axios from 'axios';

function FormPro() {
    const [formData, setFormData] = useState({ name: '', email: '', message: '' , profession:''});

    const handleSubmit = (e) => {
      e.preventDefault();
      axios.post('/send', formData)
        .then(res => {
          console.log(res);
        })
        .catch(error => {
          console.log(error);
        });
    }
  
    const handleChange = (e) => {
      setFormData({ ...formData, [e.target.name]: e.target.value });
      
    }
  return (
    <form onSubmit={handleSubmit}>
    <div className="mb-3">
        <label htmlFor="Votre nom" className="form-label">Votre nom</label>
        <input
        className="form-control"
        type="text"
        name="name"
        placeholder="Votre nom"
        value={formData.name}
        onChange={handleChange}
        />
    </div>
    <div className="mb-3">
         <label htmlFor="Votre e-mail" className="form-label">Votre e-mail</label>
        <input
        className="form-control"
        type="email"
        name="email"
        placeholder="Votre e-mail"
        value={formData.email}
        onChange={handleChange}
        />
    </div>
    <div className="mb-3">
         <label htmlFor="profession" className="form-label">profession</label>
        <select name="profession" value={formData.pro} onChange={handleChange} className="form-control">
            <option value="architecte">Architecte</option>
            <option value="Décorateur">Décorateur d’intérieur Bureau d’étude</option>
            <option value="Distributeur">Distributeur</option>
            <option value="Promoteur ">Promoteur immobilier</option>
        </select>
    </div>
    <div className="mb-3">
        <label htmlFor="Message" className="form-label">Message</label>
        <textarea
        cols="40" rows="10"
        className="form-control"
        name="message"
        placeholder="Message"
        value={formData.message}
        onChange={handleChange}
        />
    </div>
    <button type="submit">Envoyer</button>
  </form>
  )
}

export default FormPro