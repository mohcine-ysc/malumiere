

const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'djxman05@gmail.com',
    pass: 'hanoune-xman'
  }
});

app.post('/send', (req, res) => {
    const mailOptions = {
      from: req.body.email,
      to: 'mohcine.graphiste@gmail.com',
      subject: 'New message from contact form',
      text: req.body.message
    };
  
    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        console.log(error);
        res.status(500).send(error);
      } else {
        console.log('Email sent: ' + info.response);
        res.status(200).send('Email sent: ' + info)}