import React from 'react'
import Slider1 from "../components/slides/SlidesFul";
import SlidesPromo from "../components/slides/SlidesPromo";
import SlidesBlog from "../components/slides/SlidesBlog";

import {  Link } from 'react-router-dom';
function Home() {
  return (
    <div>
            <Slider1/>
            <div className="container-fluid">
            <h2 className="text-center my-5 tit">Nos promotions</h2>
            <div className="mx-2">
                <SlidesPromo/>
            <center> <Link to='/promo' className="btn btn-warning btn-lg mt-3 text-center homeB">
                    Découvrez nos promotions
                </Link></center>
            </div>
            
            </div>
            <div className="container-fluid my-5">
            <h2 className="text-center my-5 tit">Nouvelle Collection</h2>
            <div className="mx-2">
            <SlidesPromo/>
            <center> <Link to='/new' className="btn btn-warning btn-lg  mt-3 text-center homeB">
                Découvrez notre nouvelle collection
                </Link></center>
            </div>
        </div>
        <div className="container-fluid my-5">
            <h2 className="text-center my-5 tit">Les belles idées de notre blog</h2>
            <div className="mx-2">
            <SlidesBlog/>
            </div>
        </div>
    </div>
  )
}

export default Home
