import React from 'react'
import Products from '../components/products/Products'

function New() {
  return (

    <div className="container my-5">
    <div className="row">
       <Products/>
    </div>
      
    </div>

  )
}

export default New