
import { AiOutlineHeart ,AiOutlineShoppingCart} from "react-icons/ai";
import React,{useState,useEffect} from 'react';


function Shop() {
  const [data,setData]=useState([]);
  const getData=()=>{
    fetch('data/data.json'
    ,{
      headers : { 
        'Content-Type': 'application/json',
        'Accept': 'application/json'
       }
    }
    )
      .then(function(response){
        return response.json();
      })
      .then(function(myJson) {
        setData(myJson)
      });
  }
  useEffect(()=>{
    getData()
  },[])
  return (

    <div className="container my-5">
    <div className='row'>
    {
      data.map((product)=>(
        <div className="col-md-3 col-sm-6" key={product.ID}>
              <div className="card">
              <div className="position-relative">
                  <img src={product.Images } className="card-img-top" alt={product.Nom}/>
              </div>
              <div className="card-body border border-0">
                  <h4 className='f-z-14'>{product.Nom}</h4>
                  <div className="d-flex justify-content-between">
                      <p  className="text-prim">{product.Tarif} DHS</p>
                      <div className="d-flex gap-2">
                      <a className="card-link" href="#"><AiOutlineHeart/></a>
                      <a className="ncard-link" href="#"><AiOutlineShoppingCart/></a>
                      </div>
                      
                    </div>
              </div>
            </div>
              </div>
    ))}
      
    </div>
    </div>

  )
}

export default Shop