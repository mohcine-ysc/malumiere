import React from 'react'
import img1 from '../images/espace-pro-img-1.webp'
import img2 from '../images/espace-pro-img-2.webp'
import FormPro from '../components/form/FormPro'

function Pro() {
  return (


    <div className="container my-5">
     <h3 className='text-center my-3'>Chez Ma lumière, nous sommes à la disposition de nos clients professionnels pour 
     leur proposer des produits et devis adaptés à leurs besoins
     </h3>
     <p className="text-center my-3">
        Vous êtes architecte ou décorateur d’intérieur ?
        Vous travaillez pour un bureau d’étude ou d’éclairage ?<br/>
        Vous recherchez une gamme de luminaires décoratifs chics et originaux pour équiper vos projets?<br/>
        Vous êtes exactement là où il faut être !
      </p>
      <div className="row align-items-center my-3">
      <div className="col-md-6 col-xs-12">
        <img src={img1} alt="espace-pro-img" className='w-100' />
        </div>
        <div className="col-md-6 col-sm-12">
          <p className=''>
          Nos équipes riches d’une expérience de plus de 15 ans dans le secteur de
           l’éclairage sont à votre écoute afin d’étudier ensemble vos exigences et vous présenter 
           les solutions adaptées à votre projet tout en alliant optimisation technique et luminaires designs.
          Pour pouvoir satisfaire au mieux vos besoins d’équipements de projets,
           nous pouvons mettre en place des études d’éclairage que nous discuterons ensemble pour vous assurer
           le meilleur rendu lumineux possible.
          </p>
        </div>
      </div>
      <div className="row align-items-center my-3">
      <div className="col-md-6 col-sm-12">
      <p className='mb-5'>Remplissez le formulaire de contact ci-dessous afin qu’un de nos 
         spécialistes puissent prendre contact avec vous au plus vite.
      </p>
            <FormPro/>
        </div>
      <div className="col-md-6 col-xs-12">
        <img src={img2} alt="espace-pro-img" className='w-100' />
        </div>

      </div>
    </div>

  )
}

export default Pro