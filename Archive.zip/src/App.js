
import { Route, Routes } from "react-router-dom"
import Home from "./pages/home";
import New from './pages/new';
import Promo from './pages/promo';
import Pro from './pages/Pro';
import Header from "./components/header/Header";
import Footer from "./components/header/Footer";
import Shop from "./pages/shop";

function App() {
  return (
    <div>
      <Header />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/shop" element={<Shop />} />
          <Route path="/new" element={<New />} />
          <Route path="/promo" element={<Promo />} />
          <Route path="/espace-pro" element={<Pro />} />
        </Routes>
      <Footer/>
    </div>
  );
}

export default App;
